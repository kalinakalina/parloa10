import os
from pathlib import Path
from typing import List, Tuple
import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SRC = Path("/mnt/data/parloa_screenshots")  # drop screenshots here
INV = ROOT / "inventory" / "visual-inventory.csv"
ICON_DIR = ROOT / "assets" / "icons"
LOGO_DIR = ROOT / "assets" / "logos"
ILL_DIR = ROOT / "assets" / "illustrations"

ICON_DIR.mkdir(parents=True, exist_ok=True)
LOGO_DIR.mkdir(parents=True, exist_ok=True)
ILL_DIR.mkdir(parents=True, exist_ok=True)

def save_svg_from_contours(svg_path: Path, contours: List[np.ndarray], view_w: int, view_h: int, fill="currentColor"):
    def contour_to_path(c):
        epsilon = 0.5
        approx = cv2.approxPolyDP(c, epsilon, True)
        pts = approx.reshape(-1, 2)
        if len(pts) == 0:
            return ""
        d = "M " + " L ".join([f"{x:.2f},{y:.2f}" for x, y in pts]) + " Z"
        return d
    paths = [contour_to_path(c) for c in contours if cv2.contourArea(c) > 6]
    with open(svg_path, "w") as f:
        f.write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {view_w} {view_h}">')
        for d in paths:
            if d:
                f.write(f'<path d="{d}" fill="{fill}"/>\n')
        f.write('</svg>')

def detect_icon_regions(img: np.ndarray) -> List[Tuple[int,int,int,int]]:
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 80, 160)
    kernel = np.ones((3,3), np.uint8)
    edges = cv2.dilate(edges, kernel, iterations=1)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    boxes = []
    H, W = gray.shape[:2]
    for c in contours:
        x,y,w,h = cv2.boundingRect(c)
        if 16 <= min(w,h) <= 96 and w/h < 2.5 and h/w < 2.5:
            if w*h < (W*H)*0.15:
                boxes.append((x,y,w,h))
    boxes = sorted(boxes, key=lambda b: (b[1]//32, b[0]))
    return boxes

def extract_and_vectorize(img_path: Path):
    img = cv2.imread(str(img_path), cv2.IMREAD_UNCHANGED)
    if img is None:
        return 0
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    if img.shape[2] == 3:
        # add alpha channel
        b,g,r = cv2.split(img)
        a = np.full_like(b, 255)
        img = cv2.merge([b,g,r,a])

    H, W = img.shape[:2]
    boxes = detect_icon_regions(img)
    count = 0
    for i,(x,y,w,h) in enumerate(boxes):
        roi = img[y:y+h, x:x+w]
        alpha = roi[:,:,3]
        # build mask from alpha + luminance
        gray = cv2.cvtColor(roi[:,:,:3], cv2.COLOR_BGR2GRAY)
        _, thr = cv2.threshold(gray, 0,255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
        mask = np.maximum(alpha, thr)

        kernel = np.ones((2,2), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        svg_name = f"{img_path.stem}_icon_{i+1:02d}.svg"
        save_svg_from_contours(ICON_DIR/svg_name, contours, w, h, fill="currentColor")
        with open(INV, "a") as inv:
            inv.write(f"{img_path.name},icon,{img_path.stem}_icon_{i+1},{x},{y},{w},{h},assets/icons/{svg_name},auto-traced\n")
        count += 1
    return count

def run():
    total = 0
    for ext in ("*.png","*.jpg","*.jpeg","*.webp"):
        for p in SRC.glob(ext):
            total += extract_and_vectorize(p)
    print(f"Vectorized {total} icons from screenshots in {SRC}")

if __name__ == "__main__":
    run()
