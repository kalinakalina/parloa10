Run with:

import subprocess, sys
subprocess.run([sys.executable, '/mnt/data/parloa-design-system/scripts/process_assets.py'], check=True)
