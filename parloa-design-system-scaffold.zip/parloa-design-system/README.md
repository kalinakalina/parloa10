# Parloa Design System (Reverse-Engineered from Screenshots)

This repo houses tokens, assets, components, animations, and patterns extracted from product screenshots.

## How to use
1) Put raw screenshots into: `/mnt/data/parloa_screenshots`
2) Run `scripts/process_assets.py` (or the notebook runner note below).
3) Outputs get written under `assets/`, `components/`, and `animations/`.

## Pipeline
- Asset Detection → Precision Cropping → Vectorization → QC → Export
- High quality PNGs are traced to SVG via contour-to-path conversion.
- Low quality regions get re-drawn (geometric primitives) using token colors.

## Inventory
See `/inventory/visual-inventory.csv` for source, bbox, type, and output path.
